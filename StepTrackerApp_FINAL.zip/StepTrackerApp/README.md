# StepTracker — Enterprise-Grade Android Step Counter
### Final Year Project | Clean Architecture | Kotlin | Jetpack Compose | Material 3

---

## Architecture Overview

```
app/src/main/java/com/steptracker/app/
│
├── StepTrackerApplication.kt          # @HiltAndroidApp entry point
│
├── di/
│   └── AppModules.kt                  # DatabaseModule + RepositoryModule (Hilt)
│
├── data/                              # DATA LAYER
│   ├── local/
│   │   ├── StepTrackerDatabase.kt     # Room @Database
│   │   ├── dao/StepDao.kt             # All queries (Flow + suspend)
│   │   └── entity/StepEntity.kt       # Room @Entity (String PK)
│   ├── preferences/
│   │   └── StepPreferencesDataStore.kt # DataStore (goal, baseline, dates)
│   └── repository/
│       └── StepRepositoryImpl.kt      # Implements domain interface + mappers
│
├── domain/                            # DOMAIN LAYER (pure Kotlin, zero Android)
│   ├── model/StepRecord.kt            # Domain model with computed properties
│   ├── repository/StepRepository.kt   # Interface (abstraction)
│   └── usecase/UseCases.kt            # GetTodaySteps, GetWeekly, SetGoal, etc.
│
├── presentation/                      # PRESENTATION LAYER
│   ├── MainActivity.kt                # Single Activity, permission handling
│   ├── navigation/NavGraph.kt         # Compose NavHost with type-safe routes
│   ├── theme/
│   │   ├── Theme.kt                   # Material 3 + Dynamic Color
│   │   ├── Color.kt                   # Seed color palette tokens
│   │   └── Type.kt                    # Typography + Shapes
│   ├── home/
│   │   ├── HomeViewModel.kt           # StateFlow UiState + SharedFlow Events
│   │   └── HomeScreen.kt             # Circular ring, stats, Vico chart
│   ├── history/
│   │   └── HistoryScreen.kt          # Calendar heatmap, monthly summary
│   └── goal/
│       └── GoalScreen.kt             # Preset chips + custom input
│
└── service/
    ├── StepCounterService.kt          # Foreground Service (sensor + DB writes)
    └── BootReceiver.kt                # Restart service after reboot
```

---

## Tech Stack

| Concern             | Technology                            |
|---------------------|---------------------------------------|
| Language            | 100% Kotlin                           |
| UI                  | Jetpack Compose + Material 3          |
| Architecture        | MVVM + Clean Architecture             |
| DI                  | Dagger Hilt                           |
| Database            | Room (Flow-backed reactive queries)   |
| Preferences         | DataStore Preferences                 |
| Charts              | Vico (Compose-native)                 |
| Background          | Foreground Service (health type)      |
| Navigation          | Compose Navigation                    |
| Testing             | MockK + Turbine + Room In-Memory      |

---

## Key Engineering Decisions

### 1. String Date Primary Key
`StepEntity` uses `"yyyy-MM-dd"` as its primary key instead of a `Long` timestamp.
This avoids timezone-related bugs, is human-readable in database inspections, and
sorts lexicographically = chronologically.

### 2. TYPE_STEP_COUNTER Baseline Subtraction
The hardware pedometer counts from device boot (cumulative). We store a **baseline**
(the sensor value at service start) in DataStore and subtract it to get "today's steps."
Reboot detection is handled by checking for negative deltas.

### 3. Sensor Fallback Hierarchy
1. `TYPE_STEP_COUNTER` — DSP chip, lowest battery drain
2. `TYPE_STEP_DETECTOR` — CPU-based, fires per step
3. No sensor — graceful degradation with UI warning

### 4. Unidirectional Data Flow
Service → Repository → Room → Flow → ViewModel → Compose UI.
No component holds a reference to any component above it in the chain.

### 5. Batched DB Writes
Writes are batched every 10 steps **or** every 30 seconds (periodic job).
This minimizes SQLite I/O wake events and reduces battery drain.

---

## Setup Instructions

1. Clone the repository
2. Open in Android Studio Hedgehog or later
3. Sync Gradle (File → Sync Project with Gradle Files)
4. Run on a **physical device** (emulators don't have step sensors)
5. Grant `ACTIVITY_RECOGNITION` permission when prompted

### Minimum Requirements
- Android 8.0 (API 26) — minSdk
- Physical device with TYPE_STEP_COUNTER sensor
- Android Studio Hedgehog (2023.1.1) or later

---

## Running Tests

```bash
# Unit tests (JVM — no device needed)
./gradlew test

# Instrumented tests (device/emulator required)
./gradlew connectedAndroidTest
```

---

## Thesis Chapter Mapping

| Phase | Build Focus                  | Thesis Chapter                              |
|-------|------------------------------|---------------------------------------------|
| 1     | Setup & DI                   | System Architecture & Technology Selection  |
| 2     | Sensor & Service             | Background Processing Module Design         |
| 3     | Room & Repository            | Data Management & Persistence Strategy      |
| 4     | UI & ViewModels              | User Interface Design & Implementation      |
| 5     | Testing & Optimization       | Testing Strategy & Performance Evaluation   |

---

## Defense Q&A Summary

**Q: Why does TYPE_STEP_COUNTER need a baseline?**
A: It counts cumulatively from device boot. Subtracting the first-read value
gives "steps since app tracking started." Reboot resets it to 0 — detected
as negative delta, handled by re-establishing baseline.

**Q: How does the app survive Doze mode?**
A: Foreground Services are explicitly exempt from Doze CPU restrictions by
Android spec. TYPE_STEP_COUNTER runs on a DSP co-processor independently of
the main CPU — steps are counted even when the phone is in deep sleep.

**Q: How do you prevent data races between the Service and ViewModel?**
A: Room is the single source of truth. Service writes via suspend DAO functions
on Dispatchers.IO. ViewModel reads via Flow — Room handles SQLite WAL isolation
internally. No shared mutable state between the two components.
