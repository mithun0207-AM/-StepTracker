package com.steptracker.app.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import app.cash.turbine.test
import com.steptracker.app.data.local.StepTrackerDatabase
import com.steptracker.app.data.local.dao.StepDao
import com.steptracker.app.data.local.entity.StepEntity
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.IOException

/**
 * Instrumented Room DAO test.
 *
 * Uses Room.inMemoryDatabaseBuilder — creates a fresh in-memory database
 * for each test. No data leaks between tests, no I/O disk operations.
 *
 * Why this test is important for your thesis defense:
 * "How did you validate your data persistence layer?"
 * Answer: I wrote instrumented DAO tests that verify upsert, query,
 * and Flow emission behavior against a real (in-memory) Room database.
 *
 * Note: This test runs on an Android device/emulator (Instrumented test)
 * because Room requires the Android SQLite implementation.
 * The @RunWith(AndroidJUnit4::class) annotation indicates this.
 */
@RunWith(AndroidJUnit4::class)
class StepDaoTest {

    private lateinit var database: StepTrackerDatabase
    private lateinit var dao: StepDao

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, StepTrackerDatabase::class.java)
            .allowMainThreadQueries()   // Allowed only in tests
            .build()
        dao = database.stepDao()
    }

    @After
    @Throws(IOException::class)
    fun closeDb() {
        database.close()
    }

    // ── Tests ─────────────────────────────────────────────────────────────

    @Test
    fun upsertAndRetrieveTodaySteps() = runTest {
        val entity = StepEntity(
            dateString = "2025-07-15",
            stepCount = 5_000,
            goalSteps = 10_000
        )
        dao.upsertStepRecord(entity)

        dao.observeTodaySteps("2025-07-15").test {
            val result = awaitItem()
            assertNotNull(result)
            assertEquals(5_000, result!!.stepCount)
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun upsertUpdatesExistingRecord() = runTest {
        val initial = StepEntity("2025-07-15", 3_000, 10_000)
        val updated = StepEntity("2025-07-15", 7_500, 10_000)

        dao.upsertStepRecord(initial)
        dao.upsertStepRecord(updated)

        dao.observeTodaySteps("2025-07-15").test {
            val result = awaitItem()
            assertEquals(7_500, result!!.stepCount)
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun observeTodaySteps_emitsNull_whenNoRecordExists() = runTest {
        dao.observeTodaySteps("2025-07-15").test {
            val result = awaitItem()
            assertNull(result)
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun observeRecentDays_returnsCorrectNumberOfDays() = runTest {
        // Insert 10 days of data
        repeat(10) { i ->
            dao.upsertStepRecord(
                StepEntity(
                    dateString = "2025-07-${String.format("%02d", i + 1)}",
                    stepCount = (i + 1) * 1_000,
                    goalSteps = 10_000
                )
            )
        }

        dao.observeRecentDays(today = "2025-07-10", days = 7).test {
            val result = awaitItem()
            assertEquals(7, result.size)
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun observeMonthlySteps_returnsOnlyRecordsInMonth() = runTest {
        // Insert July and August records
        dao.upsertStepRecord(StepEntity("2025-07-14", 8_000, 10_000))
        dao.upsertStepRecord(StepEntity("2025-07-15", 9_000, 10_000))
        dao.upsertStepRecord(StepEntity("2025-08-01", 7_000, 10_000))

        dao.observeMonthlySteps("2025-07").test {
            val result = awaitItem()
            assertEquals(2, result.size)
            assertTrue(result.all { it.dateString.startsWith("2025-07") })
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun getTodayStepRecord_returnsNullWhenNotFound() = runTest {
        val result = dao.getTodayStepRecord("2025-07-15")
        assertNull(result)
    }

    @Test
    fun flowEmitsNewValue_whenRecordIsUpdated() = runTest {
        val initial = StepEntity("2025-07-15", 1_000, 10_000)
        dao.upsertStepRecord(initial)

        dao.observeTodaySteps("2025-07-15").test {
            // First emission
            assertEquals(1_000, awaitItem()!!.stepCount)

            // Update the record
            dao.upsertStepRecord(initial.copy(stepCount = 5_000))

            // Flow should re-emit with new value
            assertEquals(5_000, awaitItem()!!.stepCount)

            cancelAndIgnoreRemainingEvents()
        }
    }
}
