package com.steptracker.app.presentation

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.steptracker.app.domain.usecase.DailyStepData
import com.steptracker.app.presentation.home.HomeUiState
import com.steptracker.app.presentation.home.StepProgressRing
import com.steptracker.app.presentation.home.StatsRow
import com.steptracker.app.presentation.home.SensorUnavailableCard
import com.steptracker.app.presentation.theme.StepTrackerTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Compose UI tests — test individual composable functions in isolation.
 *
 * Key advantage of testing Composables directly:
 *   We don't need a full Activity or NavGraph. We can inject any state
 *   and assert on the rendered tree. This is the "Compose testing pyramid"
 *   approach recommended by Google.
 *
 * These tests prove to your professor that your UI is testable by design —
 * a direct consequence of the state-driven Composable architecture where
 * each UI component is a pure function of its parameters.
 */
@RunWith(AndroidJUnit4::class)
class HomeScreenComposableTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    // ── StepProgressRing ──────────────────────────────────────────────────

    @Test
    fun stepProgressRing_showsCorrectStepCount() {
        composeTestRule.setContent {
            StepTrackerTheme {
                StepProgressRing(
                    progress      = 0.75f,
                    currentSteps  = 7_500,
                    goalSteps     = 10_000,
                    isGoalReached = false
                )
            }
        }
        // Verify the formatted step count is visible
        composeTestRule.onNodeWithText("7,500").assertIsDisplayed()
    }

    @Test
    fun stepProgressRing_showsGoalAchievedBadge_whenGoalReached() {
        composeTestRule.setContent {
            StepTrackerTheme {
                StepProgressRing(
                    progress      = 1f,
                    currentSteps  = 10_000,
                    goalSteps     = 10_000,
                    isGoalReached = true
                )
            }
        }
        // The "Goal Reached!" badge should appear
        composeTestRule.onNodeWithText("🎉 Goal Reached!", useUnmergedTree = true)
            .assertExists()
    }

    @Test
    fun stepProgressRing_doesNotShowBadge_whenGoalNotReached() {
        composeTestRule.setContent {
            StepTrackerTheme {
                StepProgressRing(
                    progress      = 0.5f,
                    currentSteps  = 5_000,
                    goalSteps     = 10_000,
                    isGoalReached = false
                )
            }
        }
        composeTestRule.onNodeWithText("🎉 Goal Reached!", useUnmergedTree = true)
            .assertDoesNotExist()
    }

    // ── StatsRow ──────────────────────────────────────────────────────────

    @Test
    fun statsRow_showsDistanceAndCalories() {
        val uiState = HomeUiState(currentSteps = 10_000, dailyGoal = 10_000)
        composeTestRule.setContent {
            StepTrackerTheme {
                StatsRow(uiState = uiState)
            }
        }
        // 10,000 steps × 0.000762 = 7.62 km
        composeTestRule.onNodeWithText("7.62 km").assertIsDisplayed()
        // 10,000 steps × 0.04 = 400 kcal
        composeTestRule.onNodeWithText("400 kcal").assertIsDisplayed()
    }

    @Test
    fun statsRow_showsZeroRemainingSteps_whenGoalReached() {
        val uiState = HomeUiState(currentSteps = 12_000, dailyGoal = 10_000)
        composeTestRule.setContent {
            StepTrackerTheme {
                StatsRow(uiState = uiState)
            }
        }
        // remainingSteps.coerceAtLeast(0) → 0
        composeTestRule.onNodeWithText("0").assertIsDisplayed()
    }

    // ── SensorUnavailableCard ─────────────────────────────────────────────

    @Test
    fun sensorUnavailableCard_isVisibleAndContainsWarning() {
        composeTestRule.setContent {
            StepTrackerTheme { SensorUnavailableCard() }
        }
        composeTestRule
            .onNodeWithText("Step sensor not available on this device. Step tracking is disabled.")
            .assertIsDisplayed()
    }
}
