package com.steptracker.app.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import app.cash.turbine.test
import com.steptracker.app.data.local.StepTrackerDatabase
import com.steptracker.app.data.preferences.StepPreferencesDataStore
import com.steptracker.app.data.repository.StepRepositoryImpl
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.time.LocalDate
import java.time.format.DateTimeFormatter

/**
 * Integration test for StepRepositoryImpl.
 *
 * Tests the repository with a REAL in-memory Room database and a REAL
 * DataStore instance — no mocks. This validates that the implementation
 * correctly bridges the data sources to the domain interface.
 *
 * This level of testing demonstrates thoroughness that pure unit tests
 * with mocked DAOs cannot provide. Mention in your thesis:
 *   "The repository layer was validated via integration tests using
 *    in-memory Room instances, confirming correct entity-to-domain
 *    mapping and reactive Flow emission."
 */
@RunWith(AndroidJUnit4::class)
class StepRepositoryImplTest {

    private lateinit var database: StepTrackerDatabase
    private lateinit var prefsDataStore: StepPreferencesDataStore
    private lateinit var repository: StepRepositoryImpl

    private val today = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, StepTrackerDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        prefsDataStore = StepPreferencesDataStore(context)
        repository = StepRepositoryImpl(database.stepDao(), prefsDataStore)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun upsertAndObserveTodaySteps_returnsCorrectDomainModel() = runTest {
        repository.upsertSteps(
            dateString = today,
            stepCount  = 8_000,
            goalSteps  = 10_000
        )

        repository.observeTodaySteps().test {
            val record = awaitItem()
            assertNotNull(record)
            assertEquals(8_000, record!!.stepCount)
            assertEquals(10_000, record.goalSteps)
            assertEquals(today, record.dateString)
            assertEquals(0.8f, record.progress, 0.01f)
            assertFalse(record.isGoalReached)
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun upsertSteps_updatesExistingRecord_andFlowReEmits() = runTest {
        repository.upsertSteps(today, 3_000, 10_000)

        repository.observeTodaySteps().test {
            assertEquals(3_000, awaitItem()!!.stepCount)

            // Update
            repository.upsertSteps(today, 9_000, 10_000)
            assertEquals(9_000, awaitItem()!!.stepCount)

            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun observeTodaySteps_emitsNull_whenNoRecord() = runTest {
        repository.observeTodaySteps().test {
            assertNull(awaitItem())
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun setAndGetDailyGoal_roundTrips() = runTest {
        repository.setDailyGoal(12_500)
        assertEquals(12_500, repository.getDailyGoal())
    }

    @Test
    fun saveSensorBaseline_andGetSensorBaseline_roundTrips() = runTest {
        repository.saveSensorBaseline(50_000)
        assertEquals(50_000, repository.getSensorBaseline())
    }

    @Test
    fun saveAndGetLastActiveDate_roundTrips() = runTest {
        repository.saveLastActiveDate("2025-07-15")
        assertEquals("2025-07-15", repository.getLastActiveDate())
    }

    @Test
    fun observeRecentDays_returnsCorrectCount() = runTest {
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        val base = LocalDate.now()

        // Insert 10 days
        repeat(10) { i ->
            val date = base.minusDays(i.toLong()).format(formatter)
            repository.upsertSteps(date, (i + 1) * 1_000, 10_000)
        }

        repository.observeRecentDays(7).test {
            val records = awaitItem()
            assertEquals(7, records.size)
            cancelAndIgnoreRemainingEvents()
        }
    }
}
