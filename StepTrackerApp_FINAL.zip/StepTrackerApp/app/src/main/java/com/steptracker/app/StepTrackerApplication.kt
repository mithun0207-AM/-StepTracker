package com.steptracker.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Application class annotated with @HiltAndroidApp.
 * This triggers Hilt's code generation and acts as the root
 * of the application-level dependency graph.
 *
 * Must be declared in AndroidManifest.xml via android:name=".StepTrackerApplication"
 */
@HiltAndroidApp
class StepTrackerApplication : Application()
