package com.steptracker.app.presentation

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.steptracker.app.presentation.navigation.StepTrackerNavGraph
import com.steptracker.app.presentation.theme.StepTrackerTheme
import com.steptracker.app.service.StepCounterService
import dagger.hilt.android.AndroidEntryPoint

/**
 * Single Activity architecture — the only Activity in the app.
 * All navigation is handled by the Compose NavHost.
 *
 * Responsibilities:
 *   1. Set up Compose content with the Material 3 theme
 *   2. Request ACTIVITY_RECOGNITION permission (required API 29+)
 *   3. Request POST_NOTIFICATIONS permission (required API 33+)
 *   4. Start the StepCounterService after permissions are granted
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    // ── Permission launcher — handles the system permission dialog result ──
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val activityRecognitionGranted = permissions[Manifest.permission.ACTIVITY_RECOGNITION] ?: false
        if (activityRecognitionGranted) {
            startStepService()
        }
        // Note: POST_NOTIFICATIONS denial is handled gracefully —
        // the service still runs but without a visible notification on API 33+.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            StepTrackerTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    StepTrackerNavGraph()
                }
            }
        }

        checkAndRequestPermissions()
    }

    // ─────────────────────────────────────────────────────────────────────
    //  PERMISSION HANDLING
    // ─────────────────────────────────────────────────────────────────────

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        // ACTIVITY_RECOGNITION required for step sensor access on API 29+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (!isPermissionGranted(Manifest.permission.ACTIVITY_RECOGNITION)) {
                permissionsToRequest.add(Manifest.permission.ACTIVITY_RECOGNITION)
            }
        }

        // POST_NOTIFICATIONS required for foreground service notification on API 33+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!isPermissionGranted(Manifest.permission.POST_NOTIFICATIONS)) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        if (permissionsToRequest.isEmpty()) {
            // All permissions already granted — start service directly
            startStepService()
        } else {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    private fun isPermissionGranted(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    // ─────────────────────────────────────────────────────────────────────
    //  SERVICE MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────

    private fun startStepService() {
        val serviceIntent = StepCounterService.startIntent(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }
}
