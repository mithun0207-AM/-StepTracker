package com.steptracker.app.domain.usecase

import com.steptracker.app.domain.model.StepRecord
import com.steptracker.app.domain.repository.StepRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import javax.inject.Inject

/**
 * Use Cases — the heart of the domain layer.
 *
 * Each UseCase has a single responsibility (SRP) and is independently testable.
 * They are invoked via the invoke() operator so they read like functions at call sites:
 *   val flow = getTodayStepsUseCase()  ← clean, no .execute() boilerplate
 *
 * All UseCases are injected into ViewModels via Hilt.
 * None of these classes contain a single Android import.
 */

// ── GET TODAY'S STEPS ──────────────────────────────────────────────────────

class GetTodayStepsUseCase @Inject constructor(
    private val repository: StepRepository
) {
    operator fun invoke(): Flow<StepRecord?> = repository.observeTodaySteps()
}

// ── GET WEEKLY STEPS ───────────────────────────────────────────────────────

/**
 * Fetches the last 7 days of step data and maps it to [DailyStepData]
 * objects that include a human-readable day label for the chart axis.
 *
 * Thesis note: This mapping logic belongs in the UseCase, not the ViewModel.
 * ViewModels should only hold UI state — not transform domain data.
 */
class GetWeeklyStepsUseCase @Inject constructor(
    private val repository: StepRepository
) {
    private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    operator fun invoke(): Flow<List<DailyStepData>> =
        repository.observeRecentDays(days = 7).map { records ->
            val today = LocalDate.now()
            // Build a complete 7-day list — fill in 0 for days with no records
            (6 downTo 0).map { daysAgo ->
                val date = today.minusDays(daysAgo.toLong())
                val dateStr = date.format(dateFormatter)
                val record = records.find { it.dateString == dateStr }
                DailyStepData(
                    dateString = dateStr,
                    dateLabel = if (daysAgo == 0) "Today"
                    else date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()),
                    steps = record?.stepCount ?: 0,
                    goal = record?.goalSteps ?: 10_000,
                    isToday = daysAgo == 0
                )
            }
        }
}

data class DailyStepData(
    val dateString: String,
    val dateLabel: String,    // "Mon", "Tue", ..., "Today"
    val steps: Int,
    val goal: Int,
    val isToday: Boolean = false
) {
    val progressRatio: Float
        get() = if (goal > 0) (steps.toFloat() / goal).coerceIn(0f, 1f) else 0f

    val isGoalReached: Boolean
        get() = steps >= goal
}

// ── GET MONTHLY STEPS ──────────────────────────────────────────────────────

class GetMonthlyStepsUseCase @Inject constructor(
    private val repository: StepRepository
) {
    /**
     * @param year  e.g. 2025
     * @param month e.g. 7 (July)
     */
    operator fun invoke(year: Int, month: Int): Flow<List<StepRecord>> {
        val monthPrefix = String.format(Locale.ROOT, "%04d-%02d", year, month)
        return repository.observeMonthlySteps(monthPrefix)
    }
}

// ── SET DAILY GOAL ─────────────────────────────────────────────────────────

class SetDailyGoalUseCase @Inject constructor(
    private val repository: StepRepository
) {
    /**
     * Validates and persists the new daily step goal.
     * Validation belongs in the domain layer, not in a ViewModel.
     */
    suspend operator fun invoke(newGoal: Int): Result<Unit> {
        if (newGoal < 100) return Result.failure(
            IllegalArgumentException("Goal must be at least 100 steps")
        )
        if (newGoal > 100_000) return Result.failure(
            IllegalArgumentException("Goal cannot exceed 100,000 steps")
        )
        repository.setDailyGoal(newGoal)
        return Result.success(Unit)
    }
}

// ── OBSERVE DAILY GOAL ─────────────────────────────────────────────────────

class ObserveDailyGoalUseCase @Inject constructor(
    private val repository: StepRepository
) {
    operator fun invoke(): Flow<Int> = repository.observeDailyGoal()
}

// ── OBSERVE SENSOR AVAILABILITY ────────────────────────────────────────────

class ObserveSensorAvailabilityUseCase @Inject constructor(
    private val repository: StepRepository
) {
    operator fun invoke(): Flow<Boolean> = repository.observeSensorAvailability()
}
