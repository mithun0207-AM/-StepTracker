package com.steptracker.app.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(
    name = "step_tracker_prefs"
)

/**
 * Manages lightweight app preferences via Jetpack DataStore.
 *
 * DataStore is the modern replacement for SharedPreferences — it is:
 *   - Coroutine-safe (no ANR risk unlike SharedPreferences.commit())
 *   - Type-safe via Preferences Keys
 *   - Consistent (atomic read/write, never partial updates)
 *
 * One-shot suspend reads use .first() — the correct pattern.
 * The broken .collect { return@collect } pattern was removed.
 */
@Singleton
class StepPreferencesDataStore @Inject constructor(
    @ApplicationContext private val context: Context
) {

    // ── Keys ──────────────────────────────────────────────────────────────

    private object Keys {
        val DAILY_GOAL         = intPreferencesKey("daily_goal")
        val SENSOR_BASELINE    = intPreferencesKey("sensor_baseline")
        val LAST_ACTIVE_DATE   = stringPreferencesKey("last_active_date")
        val IS_SENSOR_AVAILABLE = booleanPreferencesKey("is_sensor_available")
        val SERVICE_RUNNING    = booleanPreferencesKey("service_running")
    }

    companion object {
        const val DEFAULT_DAILY_GOAL = 10_000
        const val NO_BASELINE = -1
    }

    // ── Safe flow accessor ────────────────────────────────────────────────

    private val safeData: Flow<Preferences>
        get() = context.dataStore.data.catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }

    // ── Reactive Flows (for UI observation) ───────────────────────────────

    val dailyGoalFlow: Flow<Int>
        get() = safeData.map { it[Keys.DAILY_GOAL] ?: DEFAULT_DAILY_GOAL }

    val isSensorAvailableFlow: Flow<Boolean>
        get() = safeData.map { it[Keys.IS_SENSOR_AVAILABLE] ?: true }

    // ── One-shot suspend reads (correct pattern: .first()) ────────────────

    suspend fun getDailyGoal(): Int =
        safeData.map { it[Keys.DAILY_GOAL] ?: DEFAULT_DAILY_GOAL }.first()

    suspend fun getSensorBaseline(): Int =
        safeData.map { it[Keys.SENSOR_BASELINE] ?: NO_BASELINE }.first()

    suspend fun getLastActiveDate(): String =
        safeData.map { it[Keys.LAST_ACTIVE_DATE] ?: "" }.first()

    // ── Writes ────────────────────────────────────────────────────────────

    suspend fun saveDailyGoal(goal: Int) {
        context.dataStore.edit { it[Keys.DAILY_GOAL] = goal }
    }

    suspend fun saveSensorBaseline(baseline: Int) {
        context.dataStore.edit { it[Keys.SENSOR_BASELINE] = baseline }
    }

    suspend fun saveLastActiveDate(date: String) {
        context.dataStore.edit { it[Keys.LAST_ACTIVE_DATE] = date }
    }

    suspend fun setSensorAvailable(available: Boolean) {
        context.dataStore.edit { it[Keys.IS_SENSOR_AVAILABLE] = available }
    }

    suspend fun setServiceRunning(running: Boolean) {
        context.dataStore.edit { it[Keys.SERVICE_RUNNING] = running }
    }
}
