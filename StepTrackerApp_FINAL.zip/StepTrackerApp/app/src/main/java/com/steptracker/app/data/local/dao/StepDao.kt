package com.steptracker.app.data.local.dao

import androidx.room.*
import com.steptracker.app.data.local.entity.StepEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for step records.
 *
 * All queries that drive the UI return Flow<T> — Room automatically
 * re-emits whenever the underlying table rows change. This is what
 * makes the step count update live on screen without polling.
 *
 * The suspend functions (non-Flow) are used by the Foreground Service
 * for one-shot writes and the boot-restore logic.
 */
@Dao
interface StepDao {

    /**
     * Insert or replace a step record.
     * OnConflictStrategy.REPLACE handles the "same day, updated count" case.
     * Called from the Foreground Service on every step batch flush.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStepRecord(stepEntity: StepEntity)

    /**
     * Live observation of today's step record.
     * Returns null Flow emission if no record exists yet today
     * (e.g., first launch of the day before any steps are taken).
     * The UI handles the null case by showing 0 steps.
     */
    @Query("SELECT * FROM step_records WHERE dateString = :dateString LIMIT 1")
    fun observeTodaySteps(dateString: String): Flow<StepEntity?>

    /**
     * Returns the most recent [days] records as a live Flow.
     * Used for the weekly/monthly chart screens.
     * Ordered DESC so index 0 is always the most recent day.
     */
    @Query(
        """
        SELECT * FROM step_records
        WHERE dateString <= :today
        ORDER BY dateString DESC
        LIMIT :days
        """
    )
    fun observeRecentDays(today: String, days: Int): Flow<List<StepEntity>>

    /**
     * Returns all records for a given month (e.g., monthPrefix = "2025-07").
     * Used for the calendar heatmap in the History screen.
     */
    @Query(
        """
        SELECT * FROM step_records
        WHERE dateString LIKE :monthPrefix || '-%'
        ORDER BY dateString ASC
        """
    )
    fun observeMonthlySteps(monthPrefix: String): Flow<List<StepEntity>>

    /**
     * One-shot (non-Flow) fetch — used only in the Foreground Service
     * to restore today's already-persisted step count after a service restart,
     * so we don't accidentally reset the displayed count to 0.
     */
    @Query("SELECT * FROM step_records WHERE dateString = :dateString LIMIT 1")
    suspend fun getTodayStepRecord(dateString: String): StepEntity?

    /**
     * Delete all records older than [cutoffDate].
     * Can be called during periodic cleanup to prevent unbounded DB growth.
     * Example: delete records older than 1 year.
     */
    @Query("DELETE FROM step_records WHERE dateString < :cutoffDate")
    suspend fun deleteRecordsOlderThan(cutoffDate: String)
}
