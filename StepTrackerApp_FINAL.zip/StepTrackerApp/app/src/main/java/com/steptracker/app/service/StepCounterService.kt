package com.steptracker.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.steptracker.app.R
import com.steptracker.app.domain.repository.StepRepository
import com.steptracker.app.presentation.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import javax.inject.Inject

/**
 * ─────────────────────────────────────────────────────────────────────────
 *  STEP COUNTER FOREGROUND SERVICE
 * ─────────────────────────────────────────────────────────────────────────
 *
 *  Architecture principle: the ONLY class that touches SensorManager.
 *  Writes exclusively to the Repository. UI observes the Room DB via Flow.
 *
 *  Battery strategy:
 *  TYPE_STEP_COUNTER runs on a dedicated low-power DSP co-processor.
 *  The main CPU does NOT need to be awake for steps to be counted.
 *  We use SENSOR_DELAY_NORMAL (200ms) and batch DB writes every 10 steps
 *  OR 30s — whichever comes first — to minimise I/O wake events.
 *
 *  Doze mode:
 *  Foreground Services are exempt from Doze CPU restrictions by Android
 *  spec. The persistent notification is not just UX — it grants this
 *  exemption legally under Android's foreground service contract.
 * ─────────────────────────────────────────────────────────────────────────
 */
@AndroidEntryPoint
class StepCounterService : Service(), SensorEventListener {

    @Inject
    lateinit var stepRepository: StepRepository

    private lateinit var sensorManager: SensorManager
    private var stepCounterSensor: Sensor? = null
    private var stepDetectorSensor: Sensor? = null

    /**
     * TYPE_STEP_COUNTER counts from device boot (cumulative).
     * We subtract this baseline to get "steps since tracking started today".
     * Value = BASELINE_NOT_SET until first sensor event arrives.
     */
    private var sensorBaseline: Int = BASELINE_NOT_SET

    /** Total steps confirmed flushed to Room this session */
    private var lastFlushedTotal: Int = 0

    /** Step accumulator for TYPE_STEP_DETECTOR fallback */
    private var detectorAccumulator: Int = 0

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var periodicFlushJob: Job? = null

    private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    // ─────────────────────────────────────────────────────────────────────
    //  COMPANION
    // ─────────────────────────────────────────────────────────────────────

    companion object {
        const val NOTIFICATION_ID   = 1001
        const val CHANNEL_ID        = "step_tracker_service_channel"
        const val STEP_BATCH_SIZE   = 10          // Steps between DB writes
        const val FLUSH_INTERVAL_MS = 30_000L     // Periodic flush (30 s)
        const val BASELINE_NOT_SET  = -1

        const val ACTION_START = "com.steptracker.ACTION_START"
        const val ACTION_STOP  = "com.steptracker.ACTION_STOP"

        fun startIntent(context: Context): Intent =
            Intent(context, StepCounterService::class.java).apply {
                action = ACTION_START
            }

        fun stopIntent(context: Context): Intent =
            Intent(context, StepCounterService::class.java).apply {
                action = ACTION_STOP
            }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  LIFECYCLE
    // ─────────────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        sensorManager     = getSystemService(SENSOR_SERVICE) as SensorManager
        stepCounterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        stepDetectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                serviceScope.launch {
                    flushToDBSuspend()
                    stepRepository.saveLastActiveDate(LocalDate.now().format(dateFormatter))
                }
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                // Android requires startForeground() within 5 s of startForegroundService().
                postForegroundNotification(steps = 0)
                serviceScope.launch { restoreSessionState() }
                registerBestAvailableSensor()
                startPeriodicFlushJob()
            }
        }
        // START_STICKY: if killed under memory pressure, Android restarts it.
        // The null intent on restart hits the else branch and re-initialises.
        return START_STICKY
    }

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        periodicFlushJob?.cancel()
        // Final flush on graceful destroy
        runBlocking(Dispatchers.IO) { flushToDBSuspend() }
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ─────────────────────────────────────────────────────────────────────
    //  SENSOR REGISTRATION — 3-TIER FALLBACK
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Tier 1: TYPE_STEP_COUNTER  — DSP chip, best accuracy, lowest battery.
     * Tier 2: TYPE_STEP_DETECTOR — CPU-based, one event per step, higher drain.
     * Tier 3: No sensor          — notify user, stop service gracefully.
     *
     * ~95 % of Android phones shipped after 2016 have TYPE_STEP_COUNTER.
     * The fallback chain covers budget devices, tablets, and emulators.
     */
    private fun registerBestAvailableSensor() {
        when {
            stepCounterSensor != null -> sensorManager.registerListener(
                this,
                stepCounterSensor,
                SensorManager.SENSOR_DELAY_NORMAL   // 200,000 µs — lowest wake frequency
            )
            stepDetectorSensor != null -> sensorManager.registerListener(
                this,
                stepDetectorSensor,
                SensorManager.SENSOR_DELAY_NORMAL
            )
            else -> {
                serviceScope.launch { stepRepository.setSensorUnavailable(unavailable = true) }
                stopSelf()
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  SENSOR CALLBACKS
    // ─────────────────────────────────────────────────────────────────────

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        when (event.sensor.type) {
            Sensor.TYPE_STEP_COUNTER  -> handleStepCounter(event)
            Sensor.TYPE_STEP_DETECTOR -> handleStepDetector()
        }
    }

    /**
     * TYPE_STEP_COUNTER delivers cumulative step count since DEVICE BOOT.
     *
     * Example:
     *   Phone booted 3 days ago → 50,000 total steps at that point.
     *   Our service starts today → first event value = 50,423.
     *   sensorBaseline = 50,423.
     *   User walks 100 more steps → event value = 50,523.
     *   Steps today = 50,523 − 50,423 = 100. ✓
     *
     * Reboot detection:
     *   After reboot, sensor resets to 0.
     *   rawValue (0) < sensorBaseline (50,423) → negative delta detected.
     *   Fix: re-establish baseline = rawValue (0).
     *   Previously accumulated steps are already safe in Room.
     */
    private fun handleStepCounter(event: SensorEvent) {
        val rawValue = event.values[0].toInt()

        if (sensorBaseline == BASELINE_NOT_SET) {
            sensorBaseline = rawValue
            serviceScope.launch { stepRepository.saveSensorBaseline(sensorBaseline) }
            return
        }

        // Reboot guard — raw value jumped backwards
        if (rawValue < sensorBaseline) {
            sensorBaseline = rawValue
            return
        }

        val stepsToday   = rawValue - sensorBaseline
        val newStepsDelta = stepsToday - lastFlushedTotal

        if (newStepsDelta >= STEP_BATCH_SIZE) {
            lastFlushedTotal = stepsToday
            serviceScope.launch { flushToDBSuspend(stepsToday) }
            updateNotification(steps = stepsToday)
        }
    }

    /**
     * TYPE_STEP_DETECTOR fires exactly once per step (event.values[0] == 1.0f always).
     * We manually accumulate and batch-flush every STEP_BATCH_SIZE steps.
     */
    private fun handleStepDetector() {
        detectorAccumulator++
        if (detectorAccumulator % STEP_BATCH_SIZE == 0) {
            val total = lastFlushedTotal + detectorAccumulator
            lastFlushedTotal = total
            serviceScope.launch { flushToDBSuspend(total) }
            updateNotification(steps = total)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Step sensors do not report accuracy changes — required override only.
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DATABASE FLUSH
    // ─────────────────────────────────────────────────────────────────────

    private suspend fun flushToDBSuspend(currentTotal: Int = lastFlushedTotal) {
        val today = LocalDate.now().format(dateFormatter)
        val goal  = stepRepository.getDailyGoal()
        stepRepository.upsertSteps(
            dateString = today,
            stepCount  = currentTotal,
            goalSteps  = goal
        )
    }

    /**
     * Timed flush job — ensures data is never more than FLUSH_INTERVAL_MS stale.
     * Also handles the midnight day-boundary crossing.
     */
    private fun startPeriodicFlushJob() {
        periodicFlushJob = serviceScope.launch {
            while (isActive) {
                delay(FLUSH_INTERVAL_MS)
                flushToDBSuspend()
                checkForMidnightCrossover()
            }
        }
    }

    /**
     * Detects when the calendar date changes (midnight crossover).
     * Resets all in-memory accumulators for the new day.
     * The previous day's data is already safely persisted in Room.
     */
    private suspend fun checkForMidnightCrossover() {
        val today          = LocalDate.now().format(dateFormatter)
        val lastActiveDate = stepRepository.getLastActiveDate()

        if (lastActiveDate.isNotEmpty() && lastActiveDate != today) {
            // Day has changed — reset in-memory state
            sensorBaseline      = BASELINE_NOT_SET
            lastFlushedTotal    = 0
            detectorAccumulator = 0
            stepRepository.saveLastActiveDate(today)
        } else if (lastActiveDate.isEmpty()) {
            stepRepository.saveLastActiveDate(today)
        }
    }

    /**
     * Called on START_STICKY re-launch (after system killed the service).
     * Restores the sensor baseline so the step count does not appear
     * to reset to 0 when the service restarts mid-day.
     */
    private suspend fun restoreSessionState() {
        val savedBaseline = stepRepository.getSensorBaseline()
        if (savedBaseline != BASELINE_NOT_SET) {
            sensorBaseline = savedBaseline
        }
        val today = LocalDate.now().format(dateFormatter)
        stepRepository.saveLastActiveDate(today)
    }

    // ─────────────────────────────────────────────────────────────────────
    //  NOTIFICATION
    // ─────────────────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW   // No sound, no vibration, but persistent
        ).apply {
            description = getString(R.string.notification_channel_description)
            setShowBadge(false)
            enableVibration(false)
            enableLights(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(steps: Int): Notification {
        val tapIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_content, steps))
            .setSmallIcon(R.drawable.ic_notification_steps)
            .setContentIntent(tapIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun postForegroundNotification(steps: Int) {
        val notification = buildNotification(steps)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(steps: Int) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(steps))
    }
}
