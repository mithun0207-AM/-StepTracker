package com.steptracker.app.presentation.goal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.steptracker.app.domain.usecase.ObserveDailyGoalUseCase
import com.steptracker.app.domain.usecase.SetDailyGoalUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class GoalUiState(
    val currentGoal: Int = 10_000,
    val isSaving: Boolean = false,
    val saveSuccess: Boolean = false,
    val errorMessage: String? = null
)

@HiltViewModel
class GoalViewModel @Inject constructor(
    private val observeDailyGoalUseCase: ObserveDailyGoalUseCase,
    private val setDailyGoalUseCase: SetDailyGoalUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(GoalUiState())
    val uiState: StateFlow<GoalUiState> = _uiState.asStateFlow()

    init {
        observeDailyGoalUseCase()
            .onEach { goal -> _uiState.update { it.copy(currentGoal = goal) } }
            .launchIn(viewModelScope)
    }

    fun saveGoal(newGoal: Int) {
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, errorMessage = null) }
            setDailyGoalUseCase(newGoal)
                .onSuccess {
                    _uiState.update { it.copy(isSaving = false, saveSuccess = true) }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(isSaving = false, errorMessage = error.message)
                    }
                }
        }
    }

    fun clearSuccessFlag() = _uiState.update { it.copy(saveSuccess = false) }
}
