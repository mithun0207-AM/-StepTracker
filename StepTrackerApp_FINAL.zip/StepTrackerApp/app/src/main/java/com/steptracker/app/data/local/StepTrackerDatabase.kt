package com.steptracker.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.steptracker.app.data.local.dao.StepDao
import com.steptracker.app.data.local.entity.StepEntity

/**
 * Room Database definition.
 *
 * exportSchema = true: Room exports a JSON schema file to /schemas on each
 * version bump. This file should be committed to version control — it gives
 * you a complete migration history and is required for proper AutoMigrations.
 *
 * Version bump checklist (mention in thesis):
 *   1. Increment version number
 *   2. Add a Migration object OR use @AutoMigration(from = X, to = Y)
 *   3. The exported schema file will be updated automatically by KSP
 */
@Database(
    entities = [StepEntity::class],
    version = 1,
    exportSchema = true
)
abstract class StepTrackerDatabase : RoomDatabase() {

    abstract fun stepDao(): StepDao

    companion object {
        const val DATABASE_NAME = "step_tracker_db"
    }
}
