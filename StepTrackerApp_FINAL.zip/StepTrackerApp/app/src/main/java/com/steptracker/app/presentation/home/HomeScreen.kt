package com.steptracker.app.presentation.home

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.patrykandpatrick.vico.compose.cartesian.CartesianChartHost
import com.patrykandpatrick.vico.compose.cartesian.axis.rememberBottomAxis
import com.patrykandpatrick.vico.compose.cartesian.axis.rememberStartAxis
import com.patrykandpatrick.vico.compose.cartesian.layer.rememberColumnCartesianLayer
import com.patrykandpatrick.vico.compose.cartesian.rememberCartesianChart
import com.patrykandpatrick.vico.compose.common.component.rememberLineComponent
import com.patrykandpatrick.vico.compose.common.fill
import com.patrykandpatrick.vico.core.cartesian.data.CartesianChartModelProducer
import com.patrykandpatrick.vico.core.cartesian.data.columnSeries
import com.patrykandpatrick.vico.core.cartesian.layer.ColumnCartesianLayer
import com.patrykandpatrick.vico.core.common.shape.CorneredShape
import com.steptracker.app.R
import kotlinx.coroutines.flow.collectLatest

// ─────────────────────────────────────────────────────────────────────────
//  HOME SCREEN
// ─────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel = hiltViewModel(),
    onNavigateToHistory: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.events.collectLatest { event ->
            when (event) {
                is HomeUiEvent.GoalSavedSuccessfully ->
                    snackbarHostState.showSnackbar("Goal updated!")
                is HomeUiEvent.GoalSaveFailed ->
                    snackbarHostState.showSnackbar("Error: ${event.message}")
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.home_title),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(onClick = onNavigateToHistory) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = stringResource(R.string.cd_history)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        if (uiState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(24.dp))

                StepProgressRing(
                    progress = uiState.progress,
                    currentSteps = uiState.currentSteps,
                    goalSteps = uiState.dailyGoal,
                    isGoalReached = uiState.isGoalReached,
                    modifier = Modifier.size(260.dp)
                )

                Spacer(Modifier.height(28.dp))

                StatsRow(
                    uiState = uiState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                )

                Spacer(Modifier.height(20.dp))

                DailyProgressCard(
                    uiState = uiState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                )

                Spacer(Modifier.height(16.dp))

                GoalSettingCard(
                    currentGoal = uiState.dailyGoal,
                    onGoalSet = viewModel::onGoalUpdated,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                )

                if (!uiState.isSensorAvailable) {
                    Spacer(Modifier.height(16.dp))
                    SensorUnavailableCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                    )
                }

                Spacer(Modifier.height(20.dp))

                Text(
                    text = stringResource(R.string.label_weekly_overview),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                )

                Spacer(Modifier.height(8.dp))

                WeeklyStepsChart(
                    weeklyData = uiState.weeklyData,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .padding(horizontal = 16.dp)
                )

                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────
//  CIRCULAR PROGRESS RING
// ─────────────────────────────────────────────────────────────────────────

@Composable
fun StepProgressRing(
    progress: Float,
    currentSteps: Int,
    goalSteps: Int,
    isGoalReached: Boolean,
    modifier: Modifier = Modifier,
    strokeWidth: Dp = 18.dp
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(durationMillis = 1200, easing = EaseOutCubic),
        label = "ringProgress"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = if (isGoalReached) 1f else 0.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    val primaryColor       = MaterialTheme.colorScheme.primary
    val containerColor     = MaterialTheme.colorScheme.primaryContainer
    val onSurfaceVariant   = MaterialTheme.colorScheme.onSurfaceVariant
    val tertiaryColor      = MaterialTheme.colorScheme.tertiary

    Box(contentAlignment = Alignment.Center, modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokePx  = strokeWidth.toPx()
            val diameter  = size.minDimension - strokePx
            val topLeft   = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
            val arcSize   = Size(diameter, diameter)
            val startAngle = -220f
            val sweepTotal = 260f

            // Track
            drawArc(
                color = containerColor,
                startAngle = startAngle, sweepAngle = sweepTotal,
                useCenter = false, topLeft = topLeft, size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )

            // Goal-reached glow
            if (isGoalReached) {
                drawArc(
                    color = tertiaryColor.copy(alpha = glowAlpha * 0.3f),
                    startAngle = startAngle,
                    sweepAngle = sweepTotal * animatedProgress,
                    useCenter = false,
                    topLeft = Offset(topLeft.x - 4f, topLeft.y - 4f),
                    size = Size(arcSize.width + 8f, arcSize.height + 8f),
                    style = Stroke(width = strokePx + 8f, cap = StrokeCap.Round)
                )
            }

            // Progress arc
            val progressColor = if (isGoalReached) tertiaryColor else primaryColor
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(progressColor.copy(alpha = 0.5f), progressColor),
                    center = center
                ),
                startAngle = startAngle,
                sweepAngle = sweepTotal * animatedProgress,
                useCenter = false, topLeft = topLeft, size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "%,d".format(currentSteps),
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.ExtraBold,
                color = if (isGoalReached) MaterialTheme.colorScheme.tertiary
                        else MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = stringResource(R.string.label_steps),
                style = MaterialTheme.typography.bodyMedium,
                color = onSurfaceVariant
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = stringResource(R.string.label_goal_of, "%,d".format(goalSteps)),
                style = MaterialTheme.typography.bodySmall,
                color = onSurfaceVariant
            )
            if (isGoalReached) {
                Spacer(Modifier.height(6.dp))
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    shape = MaterialTheme.shapes.small
                ) {
                    Text(
                        text = stringResource(R.string.label_goal_achieved),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────
//  STATS ROW
// ─────────────────────────────────────────────────────────────────────────

@Composable
fun StatsRow(uiState: HomeUiState, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        StatCard(
            icon  = Icons.Default.DirectionsWalk,
            label = stringResource(R.string.stat_distance),
            value = "${"%.2f".format(uiState.distanceKm)} km",
            modifier = Modifier.weight(1f)
        )
        StatCard(
            icon  = Icons.Default.LocalFireDepartment,
            label = stringResource(R.string.stat_calories),
            value = "${uiState.estimatedCalories} kcal",
            modifier = Modifier.weight(1f)
        )
        StatCard(
            icon  = Icons.Default.Flag,
            label = stringResource(R.string.stat_remaining),
            value = "%,d".format(uiState.remainingSteps),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun StatCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = MaterialTheme.shapes.medium
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(icon, contentDescription = null,
                tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Text(value, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center)
            Text(label, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────
//  DAILY PROGRESS CARD
// ─────────────────────────────────────────────────────────────────────────

@Composable
fun DailyProgressCard(uiState: HomeUiState, modifier: Modifier = Modifier) {
    val animatedProgress by animateFloatAsState(
        targetValue = uiState.progress,
        animationSpec = tween(1200, easing = EaseOutCubic),
        label = "linearProgress"
    )
    Card(modifier = modifier, elevation = CardDefaults.cardElevation(1.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.label_daily_progress),
                    style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    text = "${(uiState.progress * 100).toInt()}%",
                    style = MaterialTheme.typography.titleSmall,
                    color = if (uiState.isGoalReached) MaterialTheme.colorScheme.tertiary
                            else MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = if (uiState.isGoalReached) MaterialTheme.colorScheme.tertiary
                        else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                strokeCap = StrokeCap.Round
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────
//  GOAL SETTING CARD
// ─────────────────────────────────────────────────────────────────────────

@Composable
fun GoalSettingCard(
    currentGoal: Int,
    onGoalSet: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var isEditing by remember { mutableStateOf(false) }
    var goalText  by remember(currentGoal) { mutableStateOf(currentGoal.toString()) }

    Card(modifier = modifier) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.label_daily_goal),
                    style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                IconButton(onClick = { isEditing = !isEditing }, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = if (isEditing) Icons.Default.Close else Icons.Default.Edit,
                        contentDescription = stringResource(R.string.cd_edit_goal),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            if (isEditing) {
                Spacer(Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = goalText,
                        onValueChange = { goalText = it.filter { c -> c.isDigit() } },
                        label = { Text(stringResource(R.string.label_steps)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    FilledTonalButton(onClick = {
                        goalText.toIntOrNull()?.let { onGoalSet(it); isEditing = false }
                    }) { Text(stringResource(R.string.btn_save)) }
                }
            } else {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "%,d ${stringResource(R.string.label_steps_per_day)}".format(currentGoal),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────
//  SENSOR UNAVAILABLE CARD
// ─────────────────────────────────────────────────────────────────────────

@Composable
fun SensorUnavailableCard(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(Icons.Default.Warning, contentDescription = null,
                tint = MaterialTheme.colorScheme.onErrorContainer)
            Text(
                text = stringResource(R.string.error_sensor_unavailable),
                color = MaterialTheme.colorScheme.onErrorContainer,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────
//  WEEKLY CHART — Vico
// ─────────────────────────────────────────────────────────────────────────

@Composable
fun WeeklyStepsChart(
    weeklyData: List<DailyStepData>,
    modifier: Modifier = Modifier
) {
    if (weeklyData.isEmpty()) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text(
                text = stringResource(R.string.label_no_data),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    val primaryColor  = MaterialTheme.colorScheme.primary
    val modelProducer = remember { CartesianChartModelProducer() }

    LaunchedEffect(weeklyData) {
        modelProducer.runTransaction {
            columnSeries { series(weeklyData.map { it.steps.toFloat() }) }
        }
    }

    CartesianChartHost(
        modifier = modifier,
        chart = rememberCartesianChart(
            rememberColumnCartesianLayer(
                columnProvider = ColumnCartesianLayer.ColumnProvider.series(
                    rememberLineComponent(
                        fill  = fill(primaryColor),
                        thickness = 20.dp,
                        shape = CorneredShape.rounded(allPercent = 25)
                    )
                )
            ),
            startAxis  = rememberStartAxis(),
            bottomAxis = rememberBottomAxis(
                valueFormatter = { _, x, _ ->
                    weeklyData.getOrNull(x.toInt())?.dateLabel ?: ""
                }
            )
        ),
        modelProducer = modelProducer
    )
}
