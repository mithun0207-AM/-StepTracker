package com.steptracker.app.di

import android.content.Context
import androidx.room.Room
import com.steptracker.app.data.local.StepTrackerDatabase
import com.steptracker.app.data.local.dao.StepDao
import com.steptracker.app.data.repository.StepRepositoryImpl
import com.steptracker.app.domain.repository.StepRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

// ── DATABASE MODULE ────────────────────────────────────────────────────────

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    /**
     * Provides the Room database as a singleton.
     * fallbackToDestructiveMigration() is fine for development.
     * In production, replace with explicit Migration objects:
     *   .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
     */
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): StepTrackerDatabase =
        Room.databaseBuilder(
            context,
            StepTrackerDatabase::class.java,
            StepTrackerDatabase.DATABASE_NAME
        )
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    @Singleton
    fun provideStepDao(database: StepTrackerDatabase): StepDao = database.stepDao()
}

// ── REPOSITORY MODULE ──────────────────────────────────────────────────────

/**
 * @Binds is more efficient than @Provides for interface binding.
 * It tells Hilt: "when someone asks for StepRepository, give them StepRepositoryImpl".
 * No object instantiation happens here — Hilt handles it via the @Inject constructor.
 *
 * Must be an abstract class (not object) because @Binds requires an abstract function.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindStepRepository(
        impl: StepRepositoryImpl
    ): StepRepository
}
