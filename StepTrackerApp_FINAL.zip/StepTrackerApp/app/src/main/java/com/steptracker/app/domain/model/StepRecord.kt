package com.steptracker.app.domain.model

/**
 * Pure Kotlin domain model — zero Android framework imports.
 *
 * This is the model that flows through the domain layer (UseCases).
 * It is deliberately separate from StepEntity (data layer model).
 *
 * Why separate? If we ever change the DB schema (e.g., split stepCount
 * into morning/afternoon/evening), we update the mapper — not the domain
 * model — and nothing in the presentation layer needs to change.
 * This is the Open/Closed Principle in practice.
 */
data class StepRecord(
    val dateString: String,     // "yyyy-MM-dd"
    val stepCount: Int,
    val goalSteps: Int,
    val lastUpdated: Long
) {
    /**
     * Progress as a 0f..1f float. Computed property — derived from data,
     * not stored. Domain logic lives here, not in the ViewModel.
     */
    val progress: Float
        get() = if (goalSteps > 0) (stepCount.toFloat() / goalSteps).coerceIn(0f, 1f) else 0f

    val isGoalReached: Boolean
        get() = stepCount >= goalSteps

    /**
     * Distance estimate in kilometers.
     * Based on average stride length of 0.762m (referenced from ACSM guidelines).
     */
    val distanceKm: Float
        get() = stepCount * 0.000762f

    /**
     * Calorie estimate.
     * Based on METS calculation: ~0.04 kcal/step for average 70kg adult walking.
     */
    val estimatedCalories: Int
        get() = (stepCount * 0.04f).toInt()

    val remainingSteps: Int
        get() = (goalSteps - stepCount).coerceAtLeast(0)
}
