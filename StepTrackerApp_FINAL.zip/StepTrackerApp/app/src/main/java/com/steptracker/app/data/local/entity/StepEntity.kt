package com.steptracker.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Represents a single day's step record in the local database.
 *
 * Design decisions worth noting in your thesis:
 *
 * 1. String PK ("yyyy-MM-dd") instead of Long epoch timestamp:
 *    Long timestamps require timezone-aware conversion on every read/write.
 *    A String date is human-readable in DB inspections, timezone-safe,
 *    and sorts lexicographically = chronologically (ISO 8601 format).
 *
 * 2. goalSteps stored per-record (not just in preferences):
 *    The user's goal may change over time. Storing it per-day lets us
 *    accurately render "did you hit your goal that day?" in the history
 *    view, even if the current goal is different.
 *
 * 3. lastUpdated epoch millis: Used for cache invalidation logic and
 *    for detecting stale data after app updates.
 */
@Entity(
    tableName = "step_records",
    indices = [Index(value = ["dateString"], unique = true)]
)
data class StepEntity(
    @PrimaryKey
    val dateString: String,           // "yyyy-MM-dd" e.g. "2025-07-15"
    val stepCount: Int,               // Total steps accumulated for this day
    val goalSteps: Int,               // Daily goal at time of recording
    val lastUpdated: Long = System.currentTimeMillis()  // Epoch millis
)
