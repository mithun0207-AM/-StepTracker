package com.steptracker.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Restarts the StepCounterService after a device reboot.
 *
 * Without this receiver, the Foreground Service would stop permanently
 * whenever the user restarts their phone — losing all background tracking
 * until they manually open the app.
 *
 * Also handles MY_PACKAGE_REPLACED: restarts tracking after an app update.
 *
 * Requires: android.permission.RECEIVE_BOOT_COMPLETED in manifest.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            val serviceIntent = StepCounterService.startIntent(context)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }
}
