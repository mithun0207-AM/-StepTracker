package com.steptracker.app.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.steptracker.app.domain.usecase.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ── UI State ──────────────────────────────────────────────────────────────

data class HomeUiState(
    val currentSteps:    Int          = 0,
    val dailyGoal:       Int          = 10_000,
    val weeklyData:      List<DailyStepData> = emptyList(),
    val isSensorAvailable: Boolean    = true,
    val isLoading:       Boolean      = true,
    val goalUpdateError: String?      = null
) {
    val progress: Float
        get() = if (dailyGoal > 0) (currentSteps.toFloat() / dailyGoal).coerceIn(0f, 1f) else 0f

    val isGoalReached: Boolean
        get() = currentSteps >= dailyGoal

    /** 0.762 m average stride length (ACSM) */
    val distanceKm: Float
        get() = currentSteps * 0.000762f

    /** 0.04 kcal per step for an average 70 kg adult */
    val estimatedCalories: Int
        get() = (currentSteps * 0.04f).toInt()

    val remainingSteps: Int
        get() = (dailyGoal - currentSteps).coerceAtLeast(0)
}

// ── One-shot events (not persisted in state) ──────────────────────────────

sealed interface HomeUiEvent {
    data object GoalSavedSuccessfully      : HomeUiEvent
    data class  GoalSaveFailed(val message: String) : HomeUiEvent
}

// ── ViewModel ─────────────────────────────────────────────────────────────

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val getTodayStepsUseCase:            GetTodayStepsUseCase,
    private val getWeeklyStepsUseCase:           GetWeeklyStepsUseCase,
    private val setDailyGoalUseCase:             SetDailyGoalUseCase,
    private val observeSensorAvailabilityUseCase: ObserveSensorAvailabilityUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    /** Shared flow — 0 replay so missed events are not re-delivered on recomposition */
    private val _events = MutableSharedFlow<HomeUiEvent>(replay = 0)
    val events: SharedFlow<HomeUiEvent> = _events.asSharedFlow()

    init {
        observeTodaySteps()
        observeWeeklySteps()
        observeSensorAvailability()
    }

    private fun observeTodaySteps() {
        getTodayStepsUseCase()
            .onEach { record ->
                _uiState.update { current ->
                    current.copy(
                        currentSteps = record?.stepCount ?: 0,
                        dailyGoal    = record?.goalSteps ?: 10_000,
                        isLoading    = false
                    )
                }
            }
            .launchIn(viewModelScope)
    }

    private fun observeWeeklySteps() {
        getWeeklyStepsUseCase()
            .onEach { weekData -> _uiState.update { it.copy(weeklyData = weekData) } }
            .launchIn(viewModelScope)
    }

    private fun observeSensorAvailability() {
        observeSensorAvailabilityUseCase()
            .onEach { available -> _uiState.update { it.copy(isSensorAvailable = available) } }
            .launchIn(viewModelScope)
    }

    fun onGoalUpdated(newGoal: Int) {
        viewModelScope.launch {
            setDailyGoalUseCase(newGoal)
                .onSuccess {
                    _uiState.update { it.copy(dailyGoal = newGoal, goalUpdateError = null) }
                    _events.emit(HomeUiEvent.GoalSavedSuccessfully)
                }
                .onFailure { error ->
                    _uiState.update { it.copy(goalUpdateError = error.message) }
                    _events.emit(HomeUiEvent.GoalSaveFailed(error.message ?: "Invalid goal"))
                }
        }
    }

    fun clearGoalError() = _uiState.update { it.copy(goalUpdateError = null) }
}
