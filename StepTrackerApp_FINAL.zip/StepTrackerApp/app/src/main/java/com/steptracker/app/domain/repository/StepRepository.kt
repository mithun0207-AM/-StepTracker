package com.steptracker.app.domain.repository

import com.steptracker.app.domain.model.StepRecord
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface defined in the DOMAIN layer.
 *
 * Critical architecture point: The domain layer defines WHAT it needs,
 * not HOW it's implemented. This interface has zero awareness of Room,
 * DataStore, or any Android framework class.
 *
 * The implementation (StepRepositoryImpl) lives in the data layer and
 * is bound to this interface via Hilt in RepositoryModule.kt.
 *
 * This inversion of dependency is the "D" in SOLID — Dependency Inversion.
 * Your UseCase classes depend on this abstraction, not on the concrete
 * Room/DataStore implementation. This makes UseCases 100% unit-testable
 * with a fake/mock repository — no Android emulator required.
 */
interface StepRepository {

    // ── Observation (reactive) ────────────────────────────────────────────

    fun observeTodaySteps(): Flow<StepRecord?>

    fun observeRecentDays(days: Int): Flow<List<StepRecord>>

    fun observeMonthlySteps(monthPrefix: String): Flow<List<StepRecord>>

    fun observeDailyGoal(): Flow<Int>

    fun observeSensorAvailability(): Flow<Boolean>

    // ── One-shot reads ────────────────────────────────────────────────────

    suspend fun getDailyGoal(): Int

    suspend fun getLastActiveDate(): String

    suspend fun getSensorBaseline(): Int

    // ── Writes ────────────────────────────────────────────────────────────

    suspend fun upsertSteps(dateString: String, stepCount: Int, goalSteps: Int)

    suspend fun setDailyGoal(goal: Int)

    suspend fun saveSensorBaseline(baseline: Int)

    suspend fun saveLastActiveDate(date: String)

    suspend fun setSensorUnavailable(unavailable: Boolean)
}
