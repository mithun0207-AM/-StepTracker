package com.steptracker.app.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.steptracker.app.presentation.goal.GoalScreen
import com.steptracker.app.presentation.history.HistoryScreen
import com.steptracker.app.presentation.home.HomeScreen

/**
 * Type-safe navigation routes.
 *
 * Using sealed class + data object instead of raw strings:
 *   - Compile-time safety  (typos in "hisotry" caught at build time)
 *   - Refactor-friendly    (rename Screen.History, all usages update)
 *   - Easy argument support (add properties to the data class)
 *
 * This pattern is referenced in your thesis as an example of applying
 * type safety beyond just Kotlin's basic type system.
 */
sealed class Screen(val route: String) {
    data object Home    : Screen("home")
    data object History : Screen("history")
    data object Goal    : Screen("goal")
}

/**
 * Root navigation host for the single-Activity architecture.
 *
 * All three screens are registered here. Navigation callbacks are
 * lambdas — screens have zero knowledge of the NavController.
 * This keeps screens independently testable and reusable.
 */
@Composable
fun StepTrackerNavGraph(
    navController: NavHostController = rememberNavController(),
    startDestination: String = Screen.Home.route
) {
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                onNavigateToHistory = {
                    navController.navigate(Screen.History.route)
                }
            )
        }

        composable(Screen.History.route) {
            HistoryScreen(
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToGoal = {
                    navController.navigate(Screen.Goal.route)
                }
            )
        }

        composable(Screen.Goal.route) {
            GoalScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
