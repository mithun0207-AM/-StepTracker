package com.steptracker.app.data.repository

import com.steptracker.app.data.local.dao.StepDao
import com.steptracker.app.data.local.entity.StepEntity
import com.steptracker.app.data.preferences.StepPreferencesDataStore
import com.steptracker.app.domain.model.StepRecord
import com.steptracker.app.domain.repository.StepRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Concrete implementation of the domain's StepRepository interface.
 * Lives in the DATA layer — the only class that knows about Room & DataStore.
 *
 * Contains the Entity ↔ Domain Model mapper functions.
 *
 * Thesis architecture note:
 *   Domain layer defines: interface StepRepository
 *   Data layer implements: class StepRepositoryImpl
 *   Hilt binds them:       @Binds StepRepository → StepRepositoryImpl
 *
 * This means if we ever replace Room with SQLDelight or a remote API,
 * we replace only THIS class. Zero changes to domain or presentation layers.
 */
@Singleton
class StepRepositoryImpl @Inject constructor(
    private val stepDao: StepDao,
    private val prefsDataStore: StepPreferencesDataStore
) : StepRepository {

    private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    // ── Observation ───────────────────────────────────────────────────────

    override fun observeTodaySteps(): Flow<StepRecord?> {
        val today = LocalDate.now().format(dateFormatter)
        return stepDao.observeTodaySteps(today).map { it?.toDomainModel() }
    }

    override fun observeRecentDays(days: Int): Flow<List<StepRecord>> {
        val today = LocalDate.now().format(dateFormatter)
        return stepDao.observeRecentDays(today, days).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    override fun observeMonthlySteps(monthPrefix: String): Flow<List<StepRecord>> {
        return stepDao.observeMonthlySteps(monthPrefix).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    override fun observeDailyGoal(): Flow<Int> = prefsDataStore.dailyGoalFlow

    override fun observeSensorAvailability(): Flow<Boolean> = prefsDataStore.isSensorAvailableFlow

    // ── One-shot reads ────────────────────────────────────────────────────

    override suspend fun getDailyGoal(): Int = prefsDataStore.getDailyGoal()

    override suspend fun getLastActiveDate(): String = prefsDataStore.getLastActiveDate()

    override suspend fun getSensorBaseline(): Int = prefsDataStore.getSensorBaseline()

    // ── Writes ────────────────────────────────────────────────────────────

    override suspend fun upsertSteps(dateString: String, stepCount: Int, goalSteps: Int) {
        stepDao.upsertStepRecord(
            StepEntity(
                dateString = dateString,
                stepCount = stepCount,
                goalSteps = goalSteps,
                lastUpdated = System.currentTimeMillis()
            )
        )
    }

    override suspend fun setDailyGoal(goal: Int) = prefsDataStore.saveDailyGoal(goal)

    override suspend fun saveSensorBaseline(baseline: Int) =
        prefsDataStore.saveSensorBaseline(baseline)

    override suspend fun saveLastActiveDate(date: String) =
        prefsDataStore.saveLastActiveDate(date)

    override suspend fun setSensorUnavailable(unavailable: Boolean) =
        prefsDataStore.setSensorAvailable(!unavailable)

    // ── Mappers (Entity ↔ Domain) ─────────────────────────────────────────

    /**
     * Converts a Room entity to a domain model.
     * Private extension function — only this class needs to know about this mapping.
     * Keeps the mapping logic co-located with the class that owns both types.
     */
    private fun StepEntity.toDomainModel(): StepRecord = StepRecord(
        dateString = dateString,
        stepCount = stepCount,
        goalSteps = goalSteps,
        lastUpdated = lastUpdated
    )
}
