package com.steptracker.app.util

import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

/**
 * Pure Kotlin utility extensions.
 * Zero Android imports — fully unit-testable on JVM.
 *
 * Centralising date/format logic here means:
 *   1. The "yyyy-MM-dd" format string lives in ONE place.
 *   2. Any change to date format requires only ONE code change.
 *   3. Easy to unit-test in isolation.
 */

private val ISO_DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd")
private val MONTH_PREFIX_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM")

/** Format a LocalDate to the standard DB key format "yyyy-MM-dd". */
fun LocalDate.toDbString(): String = format(ISO_DATE_FORMATTER)

/** Format a YearMonth to the DB month prefix "yyyy-MM". */
fun YearMonth.toDbPrefix(): String = format(MONTH_PREFIX_FORMATTER)

/** Parse a "yyyy-MM-dd" string back to a LocalDate safely. */
fun String.toLocalDateOrNull(): LocalDate? = try {
    LocalDate.parse(this, ISO_DATE_FORMATTER)
} catch (e: Exception) {
    null
}

/** Format an Int step count with thousands separators: 10000 → "10,000". */
fun Int.toStepString(): String = "%,d".format(this)

/**
 * Returns a percentage string: 0.75f → "75%"
 * Clamps to 0..100 range.
 */
fun Float.toPercentString(): String =
    "${(this.coerceIn(0f, 1f) * 100).toInt()}%"

/**
 * Estimates distance in kilometres from step count.
 * Based on average stride length of 0.762 m (ACSM guidelines).
 */
fun Int.toDistanceKm(): Float = this * 0.000762f

/**
 * Estimates calories burned from step count.
 * Based on 0.04 kcal/step for an average 70 kg adult walking at moderate pace.
 * (MET calculation: MET × weight × time)
 */
fun Int.toCalories(): Int = (this * 0.04f).toInt()
