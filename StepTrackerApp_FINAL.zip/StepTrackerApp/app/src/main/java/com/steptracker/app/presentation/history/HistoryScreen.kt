package com.steptracker.app.presentation.history

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.steptracker.app.R
import com.steptracker.app.domain.model.StepRecord
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

// ─────────────────────────────────────────────────────────────────────────
//  SCREEN
//  ViewModel is defined in HistoryViewModel.kt (same package).
//  NO ViewModel or UiState classes defined here — single responsibility.
// ─────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: HistoryViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit,
    onNavigateToGoal: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.history_title)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToGoal) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = stringResource(R.string.cd_settings)
                        )
                    }
                }
            )
        }
    ) { padding ->
        if (uiState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(Modifier.height(4.dp)) }

            // ── Weekly summary stats strip ────────────────────────────────
            item {
                WeeklyStatsStrip(uiState = uiState)
            }

            // ── Month navigation header ───────────────────────────────────
            item {
                MonthNavigationRow(
                    displayMonth = uiState.displayMonth,
                    onPrevious   = viewModel::previousMonth,
                    onNext       = viewModel::nextMonth,
                    canGoForward = uiState.displayMonth < YearMonth.now()
                )
            }

            // ── Calendar heatmap ──────────────────────────────────────────
            item {
                MonthlyHeatmap(
                    yearMonth = uiState.displayMonth,
                    records   = uiState.monthlyRecords
                )
            }

            // ── Monthly summary card ──────────────────────────────────────
            item {
                MonthlySummaryCard(uiState = uiState)
            }

            // ── Daily record rows (sorted newest-first) ───────────────────
            val sortedRecords = uiState.monthlyRecords.sortedByDescending { it.dateString }
            if (sortedRecords.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = stringResource(R.string.label_no_data),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(items = sortedRecords, key = { it.dateString }) { record ->
                    DailyRecordItem(record = record)
                }
            }

            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────
//  WEEKLY STATS STRIP
// ─────────────────────────────────────────────────────────────────────────

@Composable
fun WeeklyStatsStrip(uiState: HistoryUiState) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            WeekStatItem(
                label = stringResource(R.string.summary_week_total),
                value = "%,d".format(uiState.totalStepsThisWeek)
            )
            WeekStatItem(
                label = stringResource(R.string.summary_daily_avg),
                value = "%,d".format(uiState.averageStepsPerDay)
            )
            WeekStatItem(
                label = stringResource(R.string.summary_best_day),
                value = "%,d".format(uiState.bestDaySteps)
            )
        }
    }
}

@Composable
fun WeekStatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────
//  MONTH NAVIGATION
// ─────────────────────────────────────────────────────────────────────────

@Composable
fun MonthNavigationRow(
    displayMonth: YearMonth,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    canGoForward: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onPrevious) {
            Icon(Icons.Default.ChevronLeft, stringResource(R.string.cd_prev_month))
        }
        Text(
            text = displayMonth.month.getDisplayName(TextStyle.FULL, Locale.getDefault()) +
                    " ${displayMonth.year}",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        IconButton(onClick = onNext, enabled = canGoForward) {
            Icon(Icons.Default.ChevronRight, stringResource(R.string.cd_next_month))
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────
//  MONTHLY CALENDAR HEATMAP
// ─────────────────────────────────────────────────────────────────────────

@Composable
fun MonthlyHeatmap(yearMonth: YearMonth, records: List<StepRecord>) {
    val recordMap  = records.associateBy { it.dateString }
    val formatter  = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    val firstDay   = yearMonth.atDay(1)
    // ISO: Monday = 1 → offset 0, Sunday = 7 → offset 6
    val startOffset   = firstDay.dayOfWeek.value - 1
    val daysInMonth   = yearMonth.lengthOfMonth()
    val today         = LocalDate.now()
    val dayLabels     = listOf("M", "T", "W", "T", "F", "S", "S")

    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Day-of-week header row
            Row(Modifier.fillMaxWidth()) {
                dayLabels.forEach { label ->
                    Text(
                        text      = label,
                        modifier  = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style     = MaterialTheme.typography.labelSmall,
                        color     = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(6.dp))

            val totalCells = startOffset + daysInMonth
            val rows       = (totalCells + 6) / 7

            for (row in 0 until rows) {
                Row(Modifier.fillMaxWidth()) {
                    for (col in 0 until 7) {
                        val dayNumber = row * 7 + col - startOffset + 1
                        val cellMod   = Modifier.weight(1f).aspectRatio(1f).padding(2.dp)

                        if (dayNumber < 1 || dayNumber > daysInMonth) {
                            Box(cellMod)
                        } else {
                            val date    = yearMonth.atDay(dayNumber)
                            val dateStr = date.format(formatter)
                            val record  = recordMap[dateStr]
                            HeatmapCell(
                                dayNumber = dayNumber,
                                progress  = record?.progress ?: 0f,
                                isToday   = date == today,
                                isFuture  = date.isAfter(today),
                                modifier  = cellMod
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HeatmapCell(
    dayNumber: Int,
    progress: Float,
    isToday: Boolean,
    isFuture: Boolean,
    modifier: Modifier = Modifier
) {
    val primary   = MaterialTheme.colorScheme.primary
    val surface   = MaterialTheme.colorScheme.surface

    val bgColor = when {
        isFuture          -> Color.Transparent
        isToday           -> primary
        progress <= 0f    -> surface
        progress < 0.5f   -> primary.copy(alpha = 0.25f)
        progress < 0.75f  -> primary.copy(alpha = 0.55f)
        progress < 1f     -> primary.copy(alpha = 0.80f)
        else              -> primary
    }
    val textColor = when {
        isToday  -> MaterialTheme.colorScheme.onPrimary
        isFuture -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
        else     -> MaterialTheme.colorScheme.onSurface
    }

    Box(
        modifier           = modifier.clip(CircleShape).background(bgColor),
        contentAlignment   = Alignment.Center
    ) {
        Text(
            text       = dayNumber.toString(),
            style      = MaterialTheme.typography.labelSmall,
            color      = textColor,
            fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────
//  MONTHLY SUMMARY CARD
// ─────────────────────────────────────────────────────────────────────────

@Composable
fun MonthlySummaryCard(uiState: HistoryUiState) {
    val avgMonthly = if (uiState.monthlyRecords.isNotEmpty())
        uiState.totalStepsThisMonth / uiState.monthlyRecords.size else 0

    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier                = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalArrangement   = Arrangement.SpaceEvenly
        ) {
            SummaryItem(stringResource(R.string.summary_total),     "%,d".format(uiState.totalStepsThisMonth))
            SummaryItem(stringResource(R.string.summary_avg_day),   "%,d".format(avgMonthly))
            SummaryItem(stringResource(R.string.summary_goals_hit), "${uiState.goalsHitThisMonth} ${stringResource(R.string.label_days)}")
        }
    }
}

@Composable
fun SummaryItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ─────────────────────────────────────────────────────────────────────────
//  DAILY RECORD ROW
// ─────────────────────────────────────────────────────────────────────────

@Composable
fun DailyRecordItem(record: StepRecord) {
    val displayFormatter = remember { DateTimeFormatter.ofPattern("EEE, MMM d") }
    val parseFormatter   = remember { DateTimeFormatter.ofPattern("yyyy-MM-dd") }
    val date             = LocalDate.parse(record.dateString, parseFormatter)

    Card(
        modifier  = Modifier.fillMaxWidth(),
        colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier              = Modifier.padding(horizontal = 16.dp, vertical = 12.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text       = date.format(displayFormatter),
                    style      = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text  = stringResource(R.string.label_goal_of, "%,d".format(record.goalSteps)),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text  = "%,d".format(record.stepCount),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (record.isGoalReached)
                            MaterialTheme.colorScheme.primary
                        else
                            MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text  = record.progress.let { "${(it * 100).toInt()}%" },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (record.isGoalReached) {
                    Icon(
                        imageVector        = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint               = MaterialTheme.colorScheme.primary,
                        modifier           = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
