package com.steptracker.app.presentation.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.steptracker.app.domain.model.StepRecord
import com.steptracker.app.domain.usecase.DailyStepData
import com.steptracker.app.domain.usecase.GetMonthlyStepsUseCase
import com.steptracker.app.domain.usecase.GetWeeklyStepsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import java.time.YearMonth
import javax.inject.Inject

/**
 * ViewModel for the History screen.
 *
 * Manages two parallel data streams:
 *   1. Weekly bar-chart data (last 7 days) — always live via a persistent Flow
 *   2. Monthly calendar-heatmap data — re-fetched when user changes month
 *
 * Month navigation cancels the previous Flow collection job before
 * starting a new one, preventing stale data from old months leaking
 * into the UI. This is a subtle but important correctness detail worth
 * noting in your thesis under "Reactive State Management".
 */
data class HistoryUiState(
    val monthlyRecords: List<StepRecord> = emptyList(),
    val displayMonth: YearMonth = YearMonth.now(),
    val weeklyData: List<DailyStepData> = emptyList(),
    val totalStepsThisWeek: Int = 0,
    val averageStepsPerDay: Int = 0,
    val bestDaySteps: Int = 0,
    val totalStepsThisMonth: Int = 0,
    val goalsHitThisMonth: Int = 0,
    val isLoading: Boolean = true
)

@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val getWeeklyStepsUseCase: GetWeeklyStepsUseCase,
    private val getMonthlyStepsUseCase: GetMonthlyStepsUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(HistoryUiState())
    val uiState: StateFlow<HistoryUiState> = _uiState.asStateFlow()

    private var monthJob: Job? = null

    init {
        observeWeeklyData()
        loadMonth(YearMonth.now())
    }

    private fun observeWeeklyData() {
        getWeeklyStepsUseCase()
            .onEach { weekData ->
                val total = weekData.sumOf { it.steps }
                val best  = weekData.maxOfOrNull { it.steps } ?: 0
                val avg   = if (weekData.isNotEmpty()) total / weekData.size else 0
                _uiState.update {
                    it.copy(
                        weeklyData         = weekData,
                        totalStepsThisWeek = total,
                        averageStepsPerDay = avg,
                        bestDaySteps       = best,
                        isLoading          = false
                    )
                }
            }
            .launchIn(viewModelScope)
    }

    fun loadMonth(yearMonth: YearMonth) {
        monthJob?.cancel()
        monthJob = getMonthlyStepsUseCase(yearMonth.year, yearMonth.monthValue)
            .onEach { records ->
                _uiState.update {
                    it.copy(
                        monthlyRecords      = records,
                        displayMonth        = yearMonth,
                        totalStepsThisMonth = records.sumOf { r -> r.stepCount },
                        goalsHitThisMonth   = records.count { r -> r.isGoalReached }
                    )
                }
            }
            .launchIn(viewModelScope)
    }

    fun previousMonth() = loadMonth(_uiState.value.displayMonth.minusMonths(1))
    fun nextMonth()     = loadMonth(_uiState.value.displayMonth.plusMonths(1))
}
