package com.steptracker.app.presentation

import app.cash.turbine.test
import com.steptracker.app.domain.model.StepRecord
import com.steptracker.app.domain.usecase.*
import com.steptracker.app.presentation.home.HomeUiEvent
import com.steptracker.app.presentation.home.HomeViewModel
import io.mockk.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/**
 * Unit tests for HomeViewModel.
 *
 * Key testing principles demonstrated:
 *
 * 1. No Android emulator needed — the ViewModel and UseCases are pure Kotlin.
 *    We use MockK to fake the repository, and Turbine to test Flow emissions.
 *
 * 2. TestCoroutineDispatcher replaces the real Dispatchers.Main so coroutines
 *    run synchronously in tests (no race conditions, no delays).
 *
 * 3. Turbine's Flow testing API gives us assertion power over async flows
 *    that is impossible with simple runBlocking calls.
 *
 * This test class demonstrates that Clean Architecture enables true unit testing.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModelTest {

    // ── Test Dispatcher ───────────────────────────────────────────────────

    private val testDispatcher = StandardTestDispatcher()

    // ── Mocked UseCases ───────────────────────────────────────────────────

    private val getTodayStepsUseCase: GetTodayStepsUseCase = mockk()
    private val getWeeklyStepsUseCase: GetWeeklyStepsUseCase = mockk()
    private val setDailyGoalUseCase: SetDailyGoalUseCase = mockk()
    private val observeSensorAvailabilityUseCase: ObserveSensorAvailabilityUseCase = mockk()

    private lateinit var viewModel: HomeViewModel

    // ── Sample Data ───────────────────────────────────────────────────────

    private val sampleRecord = StepRecord(
        dateString = "2025-07-15",
        stepCount = 7_500,
        goalSteps = 10_000,
        lastUpdated = System.currentTimeMillis()
    )

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)

        // Default mocks — all use cases return safe defaults
        every { getTodayStepsUseCase() } returns flowOf(sampleRecord)
        every { getWeeklyStepsUseCase() } returns flowOf(emptyList())
        every { observeSensorAvailabilityUseCase() } returns flowOf(true)

        viewModel = HomeViewModel(
            getTodayStepsUseCase,
            getWeeklyStepsUseCase,
            setDailyGoalUseCase,
            observeSensorAvailabilityUseCase
        )
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    // ── Tests ─────────────────────────────────────────────────────────────

    @Test
    fun `initial state is loading`() {
        // ViewModel is created in setUp, but coroutines haven't run yet
        // because testDispatcher is not auto-advanced
        val freshViewModel = HomeViewModel(
            getTodayStepsUseCase,
            getWeeklyStepsUseCase,
            setDailyGoalUseCase,
            observeSensorAvailabilityUseCase
        )
        assertTrue(freshViewModel.uiState.value.isLoading)
    }

    @Test
    fun `state updates correctly when step data is received`() = runTest {
        testDispatcher.scheduler.advanceUntilIdle()

        val state = viewModel.uiState.value
        assertFalse(state.isLoading)
        assertEquals(7_500, state.currentSteps)
        assertEquals(10_000, state.dailyGoal)
        assertEquals(0.75f, state.progress, 0.01f)
        assertFalse(state.isGoalReached)
    }

    @Test
    fun `isGoalReached is true when steps meet or exceed goal`() = runTest {
        val goalReachedRecord = sampleRecord.copy(stepCount = 10_000)
        every { getTodayStepsUseCase() } returns flowOf(goalReachedRecord)

        val vm = HomeViewModel(
            getTodayStepsUseCase,
            getWeeklyStepsUseCase,
            setDailyGoalUseCase,
            observeSensorAvailabilityUseCase
        )
        testDispatcher.scheduler.advanceUntilIdle()
        assertTrue(vm.uiState.value.isGoalReached)
    }

    @Test
    fun `state shows sensor unavailable when sensor not present`() = runTest {
        every { observeSensorAvailabilityUseCase() } returns flowOf(false)

        val vm = HomeViewModel(
            getTodayStepsUseCase,
            getWeeklyStepsUseCase,
            setDailyGoalUseCase,
            observeSensorAvailabilityUseCase
        )
        testDispatcher.scheduler.advanceUntilIdle()
        assertFalse(vm.uiState.value.isSensorAvailable)
    }

    @Test
    fun `onGoalUpdated emits GoalSavedSuccessfully event on success`() = runTest {
        coEvery { setDailyGoalUseCase(12_000) } returns Result.success(Unit)

        viewModel.events.test {
            viewModel.onGoalUpdated(12_000)
            testDispatcher.scheduler.advanceUntilIdle()
            assertEquals(HomeUiEvent.GoalSavedSuccessfully, awaitItem())
        }
    }

    @Test
    fun `onGoalUpdated emits GoalSaveFailed event on failure`() = runTest {
        coEvery { setDailyGoalUseCase(50) } returns Result.failure(
            IllegalArgumentException("Goal must be at least 100 steps")
        )

        viewModel.events.test {
            viewModel.onGoalUpdated(50)
            testDispatcher.scheduler.advanceUntilIdle()
            val event = awaitItem()
            assertTrue(event is HomeUiEvent.GoalSaveFailed)
            assertTrue((event as HomeUiEvent.GoalSaveFailed).message.contains("100"))
        }
    }

    @Test
    fun `null step record results in zero steps and loading false`() = runTest {
        every { getTodayStepsUseCase() } returns flowOf(null)

        val vm = HomeViewModel(
            getTodayStepsUseCase,
            getWeeklyStepsUseCase,
            setDailyGoalUseCase,
            observeSensorAvailabilityUseCase
        )
        testDispatcher.scheduler.advanceUntilIdle()

        val state = vm.uiState.value
        assertEquals(0, state.currentSteps)
        assertFalse(state.isLoading)
    }

    @Test
    fun `progress clamps to 1f when steps exceed goal`() = runTest {
        val overGoalRecord = sampleRecord.copy(stepCount = 15_000, goalSteps = 10_000)
        every { getTodayStepsUseCase() } returns flowOf(overGoalRecord)

        val vm = HomeViewModel(
            getTodayStepsUseCase,
            getWeeklyStepsUseCase,
            setDailyGoalUseCase,
            observeSensorAvailabilityUseCase
        )
        testDispatcher.scheduler.advanceUntilIdle()
        assertEquals(1f, vm.uiState.value.progress, 0.001f)
    }
}
