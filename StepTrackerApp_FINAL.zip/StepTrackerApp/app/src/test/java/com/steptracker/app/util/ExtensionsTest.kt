package com.steptracker.app.util

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

/**
 * Pure JVM unit tests for utility extension functions.
 * No Android dependencies — runs in milliseconds with no emulator.
 */
class ExtensionsTest {

    @Test
    fun `toDbString formats LocalDate correctly`() {
        val date = LocalDate.of(2025, 7, 5)
        assertEquals("2025-07-05", date.toDbString())
    }

    @Test
    fun `toDbString pads single digit month and day`() {
        val date = LocalDate.of(2025, 1, 1)
        assertEquals("2025-01-01", date.toDbString())
    }

    @Test
    fun `toDbPrefix formats YearMonth correctly`() {
        val ym = YearMonth.of(2025, 7)
        assertEquals("2025-07", ym.toDbPrefix())
    }

    @Test
    fun `toLocalDateOrNull parses valid string`() {
        val result = "2025-07-15".toLocalDateOrNull()
        assertNotNull(result)
        assertEquals(LocalDate.of(2025, 7, 15), result)
    }

    @Test
    fun `toLocalDateOrNull returns null for invalid string`() {
        assertNull("not-a-date".toLocalDateOrNull())
        assertNull("2025-13-01".toLocalDateOrNull())
        assertNull("".toLocalDateOrNull())
    }

    @Test
    fun `toStepString formats with thousands separator`() {
        assertEquals("10,000", 10_000.toStepString())
        assertEquals("1,234,567", 1_234_567.toStepString())
        assertEquals("0", 0.toStepString())
    }

    @Test
    fun `toPercentString converts float to percent`() {
        assertEquals("75%", 0.75f.toPercentString())
        assertEquals("0%", 0f.toPercentString())
        assertEquals("100%", 1f.toPercentString())
    }

    @Test
    fun `toPercentString clamps above 1f`() {
        assertEquals("100%", 1.5f.toPercentString())
    }

    @Test
    fun `toPercentString clamps below 0f`() {
        assertEquals("0%", (-0.5f).toPercentString())
    }

    @Test
    fun `toDistanceKm calculation is accurate`() {
        assertEquals(7.62f, 10_000.toDistanceKm(), 0.01f)
        assertEquals(0f, 0.toDistanceKm(), 0.001f)
    }

    @Test
    fun `toCalories calculation is accurate`() {
        assertEquals(400, 10_000.toCalories())
        assertEquals(0, 0.toCalories())
    }
}
